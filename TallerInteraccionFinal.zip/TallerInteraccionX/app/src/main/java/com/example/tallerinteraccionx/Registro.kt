package com.example.tallerinteraccionx

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.tallerinteraccionx.databinding.ActivityRegistroBinding
import kotlinx.android.synthetic.main.activity_registro.*

class Registro : AppCompatActivity() {

    private val SELECT_ACTIVITY = 50
    private var imageUri: Uri? = null

    private lateinit var binding: ActivityRegistroBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnRegresar.setOnClickListener(){
            volverMain()
        }

        binding.btnCamara.setOnClickListener(){
            abrirCamara()
        }

        binding.btnGaleria.setOnClickListener(){
            abrirGaleria()
        }

        btnGaleria.setOnClickListener {
            val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(gallery, SELECT_ACTIVITY)
        }

        binding.btnRegistrar.setOnClickListener{
            Toast.makeText(this, "El producto no ha podido registrarse", Toast.LENGTH_SHORT).show()
        }

    }

    private fun volverMain(){
        startActivity(Intent(this, MainActivity::class.java))
    }

    private fun abrirCamara(){
        startActivity(Intent(this,Camara::class.java))
    }

    private fun abrirGaleria(){
        startActivity(Intent(this,Galeria::class.java))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == SELECT_ACTIVITY) {
            imageUri = data?.data
            binding.ivImgProd.setImageURI(imageUri)
        }
    }
}

