package com.example.tallerinteraccionx

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tallerinteraccionx.databinding.ActivityGaleriaBinding
import com.example.tallerinteraccionx.databinding.ActivityRegistroBinding

class Galeria : AppCompatActivity() {
    private lateinit var binding: ActivityRegistroBinding
    val REQUEST_IMAGE = 1
}
