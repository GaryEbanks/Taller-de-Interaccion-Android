package com.example.tallerinteraccionx

data class Producto(
    val codigo: String,
    val nombre: String,
    val precio: String,
    val existencia: String,
    val IVA: String,
    val image: String
    )