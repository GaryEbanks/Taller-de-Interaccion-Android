package com.example.tallerinteraccionx

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tallerinteraccionx.databinding.ActivityListaBinding
import kotlinx.android.synthetic.main.activity_lista.*

class Lista : AppCompatActivity() {

    var productoLista: List<Producto> = listOf(
        Producto("001","RTX 3090","5000","3","30", "https://www.profesionalreview.com/wp-content/uploads/2020/10/MSI-RTX-3090-Gaming-X-Trio-24G-Review05-1280x720.jpg"),
        Producto("002", "RTX 3080ti", "4500", "1", "30", "https://m.media-amazon.com/images/I/81kf3+5l2LS._AC_SL1500_.jpg"),
        Producto("003", "RTX 3080", "4000", "6", "30", "https://m.media-amazon.com/images/I/61y+fnHvw5L._AC_SY450_.jpg"),
        Producto("004", "RTX 3070ti", "3500", "1", "30", "https://m.media-amazon.com/images/I/81ZWSNdXNSS._AC_SX450_.jpg"),
        Producto("005", "RTX 3070", "3000", "2", "30", "https://m.media-amazon.com/images/I/81XQRP5stzL._AC_SL1500_.jpg"),
        Producto("006", "RTX 3060ti", "2500", "4", "30", "https://m.media-amazon.com/images/I/818JWCrFAKL._AC_SL1500_.jpg"),
        Producto("007", "RTX 3060", "2000", "5", "30", "https://m.media-amazon.com/images/I/81iKGq2f77L._AC_SL1500_.jpg")
    )

    private lateinit var binding: ActivityListaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityListaBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        initRecycler()

        /*val bundle = intent.extras
        val dato = bundle?.getString("Datos")
        val envio = findViewById<TextView>(R.id.txtPrueba)
        envio.text = dato.toString()*/

    }
    fun initRecycler(){
        rvListaProd.layoutManager = LinearLayoutManager(this)
        val adapter = ProductoAdapter(productoLista)
        rvListaProd.adapter = adapter
    }
}