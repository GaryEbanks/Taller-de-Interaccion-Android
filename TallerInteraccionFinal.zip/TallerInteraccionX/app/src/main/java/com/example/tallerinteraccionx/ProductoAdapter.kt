package com.example.tallerinteraccionx

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_producto.view.*

class ProductoAdapter (val producto:List<Producto>):RecyclerView.Adapter<ProductoAdapter.ProdHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ProdHolder(layoutInflater.inflate(R.layout.item_producto,parent,false))
    }

    override fun getItemCount(): Int = producto.size

    override fun onBindViewHolder(holder: ProdHolder, position: Int) {
        holder.render(producto[position])
    }

    class ProdHolder(val view:View):RecyclerView.ViewHolder(view){

        fun render (producto: Producto) {
            view.tvCodigo.text = producto.codigo
            view.tvNombre.text = producto.nombre
            view.tvPrecio.text = producto.precio
            view.tvExist.text = producto.existencia
            view.tvIVA.text = producto.IVA
            Picasso.get().load(producto.image).into(view.ivProd)
            view.setOnClickListener{ Toast.makeText(view.context, "Has seleccionado a ${producto.nombre}", Toast.LENGTH_SHORT).show() }
        }
    }

}